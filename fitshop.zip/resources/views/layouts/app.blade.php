<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>fitshop</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="text-gray-900">
<nav class="navhere border-b sticky top-0 z-10">
<div class="max-w-6xl mx-auto px-4 flex items-center justify-between">
<a href="{{ route('products.index') }}" class="shop-name">FIT SHOP</a>
<img class="inline-flex items-center logo-img rounded-xl" src="{{ URL('images/l2.png') }}" alt="logo">
</div>
</nav>
<main class="max-w-6xl mx-auto p-4">
@if (session('success'))
<div class="mb-4 rounded-xl bg-green-100 border border-green-200 p-3">{{ session('success') }}</div>
@endif
@if ($errors->any())
<div class="mb-4 rounded-xl bg-red-100 border border-red-200 p-3">
<ul class="list-disc list-inside text-sm">
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
@yield('content')
</main>
</body>
</html>

<style>
body,.navhere{
background: #093028;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #237A57, #093028);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #237A57, #093028); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}

.addbart{
background: #D1913C;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #FFD194, #D1913C);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #FFD194, #D1913C); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
font-weight:bold;
}

.logo-img{width: 150px;height: 80px;}

.shop-name{color: #fff; font-size: 20px;font-weight: bold;text-shadow: 2px 4px 3px rgba(0,0,0,0.3);}

.pr_card{
background-color: #FAF9EE;
padding: 15px 10px;
border-radius: 20px;
box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
}

.btn1-show,.btn2-show,.btn3-show{
text-align: center;
padding: 10px ;
box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;
border-radius: 15px;
width: 100%;
font-weight: bold;
text-shadow: 0px 0px 6px rgba(255,255,255,0.7);
}
.btn1-show:hover,.btn2-show:hover,.btn3-show:hover{color: #FAF9EE;transition: 1s;}
.btn1-show:hover{
background: #2193b0;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #6dd5ed, #2193b0);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #6dd5ed, #2193b0); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
.btn2-show:hover{
background: #0F2027;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #2C5364, #203A43, #0F2027);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #2C5364, #203A43, #0F2027); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
.btn3-show:hover{
background: #ED213A;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #93291E, #ED213A);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #93291E, #ED213A); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
.category-part{
font-size: 14px;
color: #FAF9EE;
padding: 2px 7px;
border-radius: 10px;
text-align: center;
box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
background: #3C3B3F;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #605C3C, #3C3B3F);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #605C3C, #3C3B3F); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
.ok-search{
width: 100%;
text-align: center;
font-weight: bold;
box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;
background: #eacda3;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #d6ae7b, #eacda3);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #d6ae7b, #eacda3); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
color: #0F2027;
border-radius: 15px;
text-shadow: 0px 0px 6px rgba(255,255,255,0.7);
}

.prpage-tittle{
font-weight: bold;
text-align: center;
color: #DCCFC0;
font-size: 22px;
padding: 15px 10px;
text-shadow: 0px 15px 5px rgba(0,0,0,0.1),
10px 20px 5px rgba(0,0,0,0.05),
-10px 20px 5px rgba(0,0,0,0.05);
box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;
width: 50%;
margin: auto;
border-radius: 20px;
}
.prpage-desc{
width: 50%;
padding: 50px 10px;
margin: auto;
font-weight: bold;
color: #E8D4B7;
text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
}
.prpage-category,.prpage-price{
width: 50%;
text-align: center;
padding: 20px 10px;
margin: auto;
font-weight: bold;
color: #F6F1E9;
text-shadow: 2px 4px 3px rgba(0,0,0,0.3); 
background-color: #0F2027;
margin-top: 8px;
box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;
}

.prpage-edit{
text-align: center;
border-radius: 15px;
padding: 10px;
font-weight: bold;
color: #0F2027;
text-shadow: 1px 2px 1px rgba(80, 79, 79, 0.3); 
background: #eacda3;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #d6ae7b, #eacda3);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #d6ae7b, #eacda3);
margin-top: 75px;
box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px; 
}
.prpage-back{
text-align: center;
border-radius: 15px;
padding: 10px;
font-weight: bold;
color: #eacda3;
text-shadow: 1px 2px 1px rgba(80, 79, 79, 0.3); 
background: #232526;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #414345, #232526);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #414345, #232526); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
margin-top: 75px;
box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px; 
}

.fit-form{
width: 65%;
margin: auto;
background: #093028;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #237A57, #093028);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #237A57, #093028);
margin-top: 50px;
color: #0F2027;
padding: 15px 10px;
border-radius: 20px;
box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;
}
.fit-form input{background-color: #F6F1E9;}
.fit-form label{color: #eacda3;font-weight: bold;text-shadow: 2px 4px 3px rgba(0,0,0,0.3);padding: 2px 15px;}

.update-btn{
background-color: #d6ae7b;
color: #0F2027;
padding: 8px 35px;
box-shadow: rgba(0, 0, 0, 0.45) 0px 25px 20px -20px;
border-radius: 15px;
font-weight: bold;
text-align: center;
margin-left: 38%;
}
</style>