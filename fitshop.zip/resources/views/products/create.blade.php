@extends('layouts.app')

@section('content')
    <h1 class="prpage-tittle">Add New Product</h1>

    {{-- Show validation errors --}}
    @if ($errors->any())
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <ul class="list-disc list-inside">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- Success message --}}
    @if (session('success'))
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('products.store') }}" class="fit-form">
        @csrf

        <div>
            <label class="block text-sm mb-1">Name</label>
            <input type="text" name="name" value="{{ old('name') }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Description</label>
            <textarea name="description" class="w-full rounded-xl border p-2">{{ old('description') }}</textarea>
        </div><br>

        <div>
            <label class="block text-sm mb-1">Price</label>
            <input type="number" step="0.01" name="price" value="{{ old('price') }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Category</label>
            <input type="text" name="category_name" value="{{ old('category_name') }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <button type="submit"
                class="update-btn">
                ADD Product
            </button>
        </div><br>
    </form>
@endsection
