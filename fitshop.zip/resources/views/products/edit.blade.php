@extends('layouts.app')

@section('content')
<h1 class="prpage-tittle">Edit Product</h1>

<form method="POST" action="{{ route('products.update', $product->id) }}" class="fit-form">
        @csrf
        @method('PUT')

        <div>
            <label class="block text-sm mb-1">Product Name</label>
            <input type="text" name="name" value="{{ old('name', $product->name) }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        

        <div>
            <label class="block text-sm mb-1">Product Price</label>
            <input type="number" step="0.01" name="price" value="{{ old('price', $product->price) }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Product Category</label>
            <input type="text" name="category_name" value="{{ old('category_name', $product->category_name) }}"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Product Description</label>
            <textarea name="description" class="w-full rounded-xl border p-2">{{ old('description', $product->description) }}</textarea>
        </div><br>

        <div>
            <button type="submit"
                class="update-btn">
                Update Product 
            </button>
        </div><br>
    </form>
@endsection
