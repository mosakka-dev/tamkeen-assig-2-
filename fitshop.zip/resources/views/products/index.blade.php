@extends('layouts.app')
@section('content')
<a href="{{ route('products.create') }}" class="inline-flex items-center px-3 py-2 my-5 rounded-xl addbart text-dark">+ ADD NEW PRODUCT </a>

<form method="GET" class="grid md:grid-cols-4 gap-3 mb-6">
<input type="text" name="search" value="{{ $search }}" placeholder="Product Name" class="w-full rounded-xl border p-2" />

<select name="sort" class="w-full rounded-xl border p-2">
<option value="latest" @selected($sort==='latest')>Sort BY</option>
<option value="name_asc" @selected($sort==='name_asc')>Name A→Z</option>
<option value="name_desc" @selected($sort==='name_desc')>Name Z→A</option>
<option value="price_asc" @selected($sort==='price_asc')>Price Low→High</option>
<option value="price_desc" @selected($sort==='price_desc')>Price High→Low</option>
</select>

<select name="category" class="w-full rounded-xl border p-2">
<option value="">categorys</option>
@foreach ($categories as $c)
<option value="{{ $c }}" @selected($category === $c)>{{ $c }}</option>
@endforeach
</select>

<button class="ok-search"> OK </button>
</form>

@php use Illuminate\Support\Str; @endphp
@if ($products->count() === 0)
<div class="rounded-xl bg-white border p-6 text-center">oops you dont have a product yet</div>
@else
<div class="grid sm:grid-cols-1 lg:grid-cols-2 gap-4">
@foreach ($products as $product)

<div class="pr_card flex flex-col">
<div class="flex items-start justify-between gap-2">
<h2 class="font-semibold text-lg px-2">{{ $product->name }}</h2>
<span class="category-part">{{ $product->category_name }}</span>
</div>
<p class="text-sm text-gray-600 mt-2 line-clamp-3 px-4">{{ Str::limit($product->description, 120) }}</p>
<div class="mt-3 font-bold px-4">Only - {{ number_format($product->price, 2) }} $ </div>
<div class="mt-4 grid grid-cols-3 gap-2 text-sm">
<a class="btn1-show" href="{{ route('products.show', $product) }}">Show</a>
<a class="btn2-show" href="{{ route('products.edit', $product) }}">Edit</a>
<form method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('Are you Sure You Want delete This product?')">
@csrf
@method('DELETE')
<button class="btn3-show">Delete</button>
</form>
</div>
</div>
@endforeach
</div>

<a href="{{ route('products.create') }}" class="inline-flex items-center px-3 py-2 my-5 rounded-xl addbart text-dark">+ ADD NEW PRODUCT </a>

<div class="mt-6">{{ $products->links() }}</div>
@endif
@endsection