@extends('layouts.app')

@section('content')
<h1 class="prpage-tittle">{{ $product->name }}</h1>
<p class="prpage-desc">{{ $product->description }}</p>
<p class="prpage-category"><strong>Category : </strong> {{ $product->category_name }}</p>
<p class="prpage-price"><strong>Price : </strong> ${{ $product->price }}</p>

<div class="grid grid-cols-2 gap-5">
<a class="prpage-back" href="{{url()->previous()}}"> Go Back </a>
<a href="{{ route('products.edit', $product->id) }}" class="prpage-edit">Edit This Product</a>
</div>
@endsection
