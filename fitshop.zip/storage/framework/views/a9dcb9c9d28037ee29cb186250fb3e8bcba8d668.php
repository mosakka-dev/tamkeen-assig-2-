<?php $__env->startSection('content'); ?>
<h1 class="prpage-tittle"><?php echo e($product->name); ?></h1>
<p class="prpage-desc"><?php echo e($product->description); ?></p>
<p class="prpage-category"><strong>Category : </strong> <?php echo e($product->category_name); ?></p>
<p class="prpage-price"><strong>Price : </strong> $<?php echo e($product->price); ?></p>

<div class="grid grid-cols-2 gap-5">
<a class="prpage-back" href="<?php echo e(url()->previous()); ?>"> Go Back </a>
<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="prpage-edit">Edit This Product</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mini-catalog-laravel-main\resources\views/products/show.blade.php ENDPATH**/ ?>