<?php $__env->startSection('content'); ?>
    <h1 class="prpage-tittle">Add NEW Product</h1>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('products.store')); ?>" class="fit-form">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block text-sm mb-1">Name</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Description</label>
            <textarea name="description" class="w-full rounded-xl border p-2"><?php echo e(old('description')); ?></textarea>
        </div><br>

        <div>
            <label class="block text-sm mb-1">Price</label>
            <input type="number" step="0.01" name="price" value="<?php echo e(old('price')); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Category</label>
            <input type="text" name="category_name" value="<?php echo e(old('category_name')); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <button type="submit"
                class="update-btn">
                ADD Product
            </button>
        </div><br>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mini-catalog-laravel-main\resources\views/products/create.blade.php ENDPATH**/ ?>