<?php $__env->startSection('content'); ?>
<h1 class="prpage-tittle">Edit Product</h1>

<form method="POST" action="<?php echo e(route('products.update', $product->id)); ?>" class="fit-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block text-sm mb-1">Product Name</label>
            <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        

        <div>
            <label class="block text-sm mb-1">Product Price</label>
            <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $product->price)); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Product Category</label>
            <input type="text" name="category_name" value="<?php echo e(old('category_name', $product->category_name)); ?>"
                class="w-full rounded-xl border p-2">
        </div><br>

        <div>
            <label class="block text-sm mb-1">Product Description</label>
            <textarea name="description" class="w-full rounded-xl border p-2"><?php echo e(old('description', $product->description)); ?></textarea>
        </div><br>

        <div>
            <button type="submit"
                class="update-btn">
                Update Product 
            </button>
        </div><br>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitshop\resources\views/products/edit.blade.php ENDPATH**/ ?>