<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('products.create')); ?>" class="inline-flex items-center px-3 py-2 my-5 rounded-xl addbart text-dark">+ ADD NEW PRODUCT </a>

<form method="GET" class="grid md:grid-cols-4 gap-3 mb-6">
<input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Product Name" class="w-full rounded-xl border p-2" />

<select name="sort" class="w-full rounded-xl border p-2">
<option value="latest" <?php if($sort==='latest'): echo 'selected'; endif; ?>>Sort BY</option>
<option value="name_asc" <?php if($sort==='name_asc'): echo 'selected'; endif; ?>>Name A→Z</option>
<option value="name_desc" <?php if($sort==='name_desc'): echo 'selected'; endif; ?>>Name Z→A</option>
<option value="price_asc" <?php if($sort==='price_asc'): echo 'selected'; endif; ?>>Price Low→High</option>
<option value="price_desc" <?php if($sort==='price_desc'): echo 'selected'; endif; ?>>Price High→Low</option>
</select>

<select name="category" class="w-full rounded-xl border p-2">
<option value="">categorys</option>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($c); ?>" <?php if($category === $c): echo 'selected'; endif; ?>><?php echo e($c); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<button class="ok-search"> OK </button>
</form>

<?php use Illuminate\Support\Str; ?>
<?php if($products->count() === 0): ?>
<div class="rounded-xl bg-white border p-6 text-center">oops you dont have a product yet</div>
<?php else: ?>
<div class="grid sm:grid-cols-1 lg:grid-cols-2 gap-4">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="pr_card flex flex-col">
<div class="flex items-start justify-between gap-2">
<h2 class="font-semibold text-lg px-2"><?php echo e($product->name); ?></h2>
<span class="category-part"><?php echo e($product->category_name); ?></span>
</div>
<p class="text-sm text-gray-600 mt-2 line-clamp-3 px-4"><?php echo e(Str::limit($product->description, 120)); ?></p>
<div class="mt-3 font-bold px-4">Only - <?php echo e(number_format($product->price, 2)); ?> $ </div>
<div class="mt-4 grid grid-cols-3 gap-2 text-sm">
<a class="btn1-show" href="<?php echo e(route('products.show', $product)); ?>">Show</a>
<a class="btn2-show" href="<?php echo e(route('products.edit', $product)); ?>">Edit</a>
<form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" onsubmit="return confirm('Are you Sure You Want delete This product?')">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn3-show">Delete</button>
</form>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<a href="<?php echo e(route('products.create')); ?>" class="inline-flex items-center px-3 py-2 my-5 rounded-xl addbart text-dark">+ ADD NEW PRODUCT </a>

<div class="mt-6"><?php echo e($products->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitshop\resources\views/products/index.blade.php ENDPATH**/ ?>